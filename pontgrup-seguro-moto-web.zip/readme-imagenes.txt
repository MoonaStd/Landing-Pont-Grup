Imágenes optimizadas para web (WebP). Nombre de archivo | tamaño | peso | texto alternativo (alt)

seguro-moto-pont-grup-javi-vega.webp | 1920x1241px | 124 KB | Javi Vega, piloto de rally, celebra junto a su moto con la equipación de Pont Grup
seguro-moto-pont-grup-xavi-vierge-superbikes.webp | 1920x1241px | 82 KB | Xavi Vierge trazando una curva en Superbikes con el casco de Pont Grup
seguro-moto-pont-grup-pedro-acosta-podio.webp | 1920x1241px | 91 KB | Pedro Acosta celebra en el podio de MotoGP
seguro-moto-pont-grup-munoz-moto3.webp | 1920x1241px | 92 KB | El piloto de Moto3 Muñoz, con casco de Pont Grup, tumbado en una curva
seguro-moto-pont-grup-rueda-moto3-podio.webp | 1920x1241px | 88 KB | El piloto de Moto3 Rueda celebra con el trofeo en el podio
seguro-moto-pont-grup-lorenzo-santolino-dakar.webp | 1920x1241px | 136 KB | Lorenzo Santolino con su medalla del Dakar junto a su moto patrocinada por Pont Grup
sello-mejor-seguro-de-moto-2025-2026-strategik.svg | 582x187 (vectorial) | 67 KB | Esta moto cuenta con el mejor seguro de moto 2025 y 2026 según estudio consultora Strategik
seguro-moto-scooter-ciudad.webp | 1920x1080px | 211 KB | Motorista en scooter por una avenida de la ciudad
opinion-seguro-moto-pedro-acosta.webp | 640x960px | 31 KB | Pedro Acosta, piloto de MotoGP, con su casco de Pont Grup
opinion-seguro-moto-dani-pedrosa.webp | 640x960px | 16 KB | Dani Pedrosa, campeón del mundo de motociclismo, con una camiseta de Pont Grup
opinion-seguro-moto-xavi-vierge.webp | 640x960px | 61 KB | Xavi Vierge, piloto de Superbikes, junto a su moto
